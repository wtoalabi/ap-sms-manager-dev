<?php
	/**
	 * Created by Alabi Olawale
	 * Date: 12/07/2020
	 */
	
	namespace App\Controllers;
	
	use App\Models\Contacts\Transformer;
	use League\Fractal\Pagination\IlluminatePaginatorAdapter;
	use League\Fractal\Serializer\JsonApiSerializer;
	use Spatie\Fractalistic\Fractal;
	
	class Controller {
		public function response(  ) {
		
		}
	}
