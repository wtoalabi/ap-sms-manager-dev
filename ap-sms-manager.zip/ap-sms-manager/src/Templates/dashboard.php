<div id="apps_bay_sms_manager_dashboard">
  <index></index>
</div>
