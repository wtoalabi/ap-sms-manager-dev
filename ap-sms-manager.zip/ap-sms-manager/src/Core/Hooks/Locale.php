<?php
	/**
	 * Created by Alabi Olawale
	 * Date: 08/07/2020
	 */
	
	namespace App\Core\Hooks;
	
	
	class Locale {
		public static function Load() {
			//add_action( "", [], "", "" );
		}
	}
