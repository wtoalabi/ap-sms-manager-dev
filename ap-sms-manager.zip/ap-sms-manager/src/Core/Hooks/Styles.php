<?php
	/**
	 * Created by Alabi Olawale
	 * Date: 08/07/2020
	 */
	
	namespace App\Core\Hooks;
	
	
	use function AppsBay_Main_Config\config;
	
	class Styles {
		public static function Load() {
			$name = config( "plugin" ).'_apps_bay_sms';
			$version = config( "plugin_version" );
			$path = config( "plugin_assets" ). 'styles/app.css';
			wp_enqueue_style( $name,  $path, [],$version , "all" );
			wp_enqueue_style( "appsbay_icons",  "//cdn.materialdesignicons.com/5.3.45/css/materialdesignicons.min.css", [],$version , "all" );
		}
	}
