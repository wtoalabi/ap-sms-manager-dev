<template>
  <div>
    <v-list-item
        key="reports"
        link
        to="/reports"
    >
      <v-list-item-action>
        <v-icon>mdi-chart-areaspline</v-icon>
      </v-list-item-action>
      <v-list-item-content>
        <v-list-item-title>
          Delivery Reports
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
  </div>
</template>

<script>
  export default {
    data() {
      return {}
    },
    methods: {},
    computed: {}
  }

</script>
