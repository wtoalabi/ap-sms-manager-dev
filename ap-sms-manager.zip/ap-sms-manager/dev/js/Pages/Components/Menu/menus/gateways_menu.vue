<template>
  <div>
    <v-list-item
        key="settings"
        link
        to="/gateways/list"
    >
      <v-list-item-action>
        <v-icon>mdi-video-input-component</v-icon>
      </v-list-item-action>
      <v-list-item-content>
        <v-list-item-title>
          Gateways API Integration
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>  </div>
</template>

<script>
  export default {
    data() {
      return {}
    },
    methods: {},
    computed: {}
  }

</script>
