export default {
  reports_mutators(state, payload){
    state.reports.list = payload
  }
}
