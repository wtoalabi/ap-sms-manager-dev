export default {
  loading: false,
  miniDrawer:false,
  title: '',
  notifications: {},
}
