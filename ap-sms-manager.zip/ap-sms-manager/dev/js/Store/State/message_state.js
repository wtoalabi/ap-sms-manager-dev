export default {
  messages:{
    list:[],
    sent: false
  }
}
