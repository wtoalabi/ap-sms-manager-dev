export default {
  reports:{
    list:[],
    rowsNumber: 10
  }
}
