export default {
  contacts:{
    loaded: false,
    contactsSaved: false,
    selectAllContacts: false,
    contactSources:[],
    rowsNumber:20,
    list:[],
    selectedContacts:[]
  }
}
