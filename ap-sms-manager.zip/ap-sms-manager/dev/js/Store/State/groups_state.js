export default {
  groups:{
    metaList:[],
    list:[],
    rowsNumber:20,
  }
}
