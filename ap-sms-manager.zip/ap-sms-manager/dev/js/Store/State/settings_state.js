export default {
  settings: {
    reload: 0,
    themeColors: {
      primaryColor: null,
      secondaryColor: null,
      successColor: null,
    }
  }
}
