export default [
  {
    name: 'Settings',
    path: '/settings',
    component: () => import('@/Pages/Settings/Settings'),
  }
]
