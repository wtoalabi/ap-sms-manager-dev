export default [
  {
    name: 'Send SMS',
    path: '/send-sms',
    component: () => import('@/Pages/Send/SendSMS'),
  }
]
