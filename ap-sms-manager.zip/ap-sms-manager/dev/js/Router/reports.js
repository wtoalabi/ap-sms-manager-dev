export default [
  {
    name: 'Reports',
    path: '/reports',
    component: () => import('@/Pages/Reports/Reports'),
  }
]
