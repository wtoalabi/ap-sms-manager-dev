export default [
  {
    name: 'Add Contacts',
    path: '/add-contacts',
    component: () => import('@/Pages/AddContacts/AddContacts'),
  }
]
