# Todo
* Make theme choice persistent
* Link to plugin update from theme page
* Add names to the contact data
* Collapse Wordpress Admin Menu when plugin's menu collapsed
